LP差し替え（ABテストB終了・A/C半々）2026-10-25
Xserverファイル管理での置き場所:
  root/index.html → merone.co.jp/public_html/lp.merone.co.jp/index.html（lp.merone.co.jp のトップ）
  new/index.html  → 同フォルダ内 new/index.html
  s/index.html    → 同フォルダ内 s/index.html
各フォルダで「アップロード」→ 同名ファイルの上書きを「はい」。
